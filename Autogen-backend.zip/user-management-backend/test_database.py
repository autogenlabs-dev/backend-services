#!/usr/bin/env python3
"""Test database connection and table creation."""

from app.database import engine, SessionLocal
from app.models.user import User, OAuthProvider, SubscriptionPlan
from sqlalchemy import text
import uuid

def test_database_connection():
    """Test that we can connect to the database and tables exist."""
    try:
        # Test connection
        with engine.connect() as connection:
            result = connection.execute(text("SELECT name FROM sqlite_master WHERE type='table';"))
            tables = [row[0] for row in result]
            print("Tables in database:", tables)
            
        # Test creating a session and basic operations
        db = SessionLocal()
        try:
            # Test creating OAuth providers
            openrouter = OAuthProvider(
                name="openrouter",
                display_name="OpenRouter",
                is_active=True
            )
            glama = OAuthProvider(
                name="glama", 
                display_name="Glama",
                is_active=True
            )
            requesty = OAuthProvider(
                name="requesty",
                display_name="Requesty", 
                is_active=True
            )
            
            db.add_all([openrouter, glama, requesty])
            db.commit()
            print("✅ OAuth providers created successfully")
            
            # Test creating subscription plans
            free_plan = SubscriptionPlan(
                name="free",
                display_name="Free Plan",
                monthly_tokens=1000,
                price_monthly=0.00,
                features={"models": ["basic"], "support": "community"},
                is_active=True
            )
            
            pro_plan = SubscriptionPlan(
                name="pro", 
                display_name="Pro Plan",
                monthly_tokens=10000,
                price_monthly=9.99,
                features={"models": ["basic", "advanced"], "support": "email", "api_access": True},
                is_active=True
            )
            
            db.add_all([free_plan, pro_plan])
            db.commit()
            print("✅ Subscription plans created successfully")
            
            # Test creating a user
            test_user = User(
                email="test@example.com",
                is_active=True
            )
            
            db.add(test_user)
            db.commit()
            print("✅ Test user created successfully")
            
            # Query data back
            providers = db.query(OAuthProvider).all()
            plans = db.query(SubscriptionPlan).all()
            users = db.query(User).all()
            
            print(f"✅ Database test completed successfully!")
            print(f"   - OAuth Providers: {len(providers)}")
            print(f"   - Subscription Plans: {len(plans)}")
            print(f"   - Users: {len(users)}")
            
        finally:
            db.close()
            
    except Exception as e:
        print(f"❌ Database test failed: {e}")
        raise

if __name__ == "__main__":
    test_database_connection()
