#!/usr/bin/env python3
"""Test login directly."""

import requests

def test_login():
    """Test user login with email and password."""
    print("=== Testing User Login ===")
    
    # Test data (using form data for OAuth2PasswordRequestForm)
    login_data = {
        "username": "test@example.com",  # OAuth2PasswordRequestForm uses 'username'
        "password": "testpassword123"
    }
    
    try:
        response = requests.post(
            "http://127.0.0.1:8000/auth/login",
            data=login_data,  # Using form data, not JSON
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        print(f"Status Code: {response.status_code}")
        
        try:
            print(f"Response: {response.json()}")
        except:
            print(f"Response text: {response.text}")
        
        if response.status_code == 200:
            print("✅ Login successful!")
            token_data = response.json()
            return token_data.get("access_token")
        else:
            print("❌ Login failed!")
            return None
            
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to server. Make sure it's running on port 8000.")
        return None
    except Exception as e:
        print(f"❌ Error during login: {e}")
        return None

if __name__ == "__main__":
    test_login()
