#!/usr/bin/env python3
"""Comprehensive test of authentication endpoints."""

import requests
import json
import random
import string

# Base URL for the API
BASE_URL = "http://127.0.0.1:8000"

def generate_test_email():
    """Generate a random test email."""
    random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    return f"test_{random_suffix}@example.com"

def test_full_auth_flow():
    """Test the complete authentication flow."""
    print("=== Complete Authentication Flow Test ===\n")
    
    # Generate unique email for this test
    test_email = generate_test_email()
    test_password = "testpassword123"
    
    print(f"Using test email: {test_email}")
    
    # 1. Test OAuth providers endpoint
    print("\n1. Testing OAuth Providers...")
    try:
        response = requests.get(f"{BASE_URL}/auth/providers")
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            providers = response.json()["providers"]
            print(f"   ✅ Found {len(providers)} OAuth providers")
        else:
            print("   ❌ OAuth providers failed")
            return
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return
    
    # 2. Test user registration
    print("\n2. Testing User Registration...")
    user_data = {
        "email": test_email,
        "password": test_password
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/register",
            json=user_data,
            headers={"Content-Type": "application/json"}
        )
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            user_info = response.json()
            print(f"   ✅ User registered successfully")
            print(f"   User ID: {user_info['id']}")
            print(f"   Email: {user_info['email']}")
        else:
            print(f"   ❌ Registration failed: {response.json()}")
            return
    except Exception as e:
        print(f"   ❌ Error during registration: {e}")
        return
    
    # 3. Test user login
    print("\n3. Testing User Login...")
    login_data = {
        "username": test_email,  # OAuth2PasswordRequestForm uses 'username'
        "password": test_password
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/login",
            data=login_data,
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            token_data = response.json()
            access_token = token_data["access_token"]
            refresh_token = token_data["refresh_token"]
            print(f"   ✅ Login successful")
            print(f"   Token type: {token_data['token_type']}")
            print(f"   Access token: {access_token[:50]}...")
            print(f"   Refresh token: {refresh_token[:50]}...")
        else:
            print(f"   ❌ Login failed: {response.json()}")
            return
    except Exception as e:
        print(f"   ❌ Error during login: {e}")
        return
    
    # 4. Test protected endpoint with token
    print("\n4. Testing Protected Endpoint...")
    try:
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(f"{BASE_URL}/auth/me", headers=headers)
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            user_info = response.json()
            print(f"   ✅ Protected endpoint access successful")
            print(f"   Current user: {user_info['email']}")
            print(f"   User ID: {user_info['id']}")
            print(f"   Active: {user_info['is_active']}")
        else:
            print(f"   ❌ Protected endpoint failed: {response.json()}")
            return
    except Exception as e:
        print(f"   ❌ Error accessing protected endpoint: {e}")
        return
    
    # 5. Test invalid token
    print("\n5. Testing Invalid Token...")
    try:
        headers = {
            "Authorization": "Bearer invalid_token_here",
            "Content-Type": "application/json"
        }
        
        response = requests.get(f"{BASE_URL}/auth/me", headers=headers)
        print(f"   Status: {response.status_code}")
        if response.status_code == 401:
            print(f"   ✅ Invalid token properly rejected")
        else:
            print(f"   ❌ Invalid token not properly rejected")
    except Exception as e:
        print(f"   ❌ Error testing invalid token: {e}")
    
    # 6. Test wrong password
    print("\n6. Testing Wrong Password...")
    wrong_login_data = {
        "username": test_email,
        "password": "wrong_password"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/login",
            data=wrong_login_data,
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        print(f"   Status: {response.status_code}")
        if response.status_code == 401:
            print(f"   ✅ Wrong password properly rejected")
        else:
            print(f"   ❌ Wrong password not properly rejected")
    except Exception as e:
        print(f"   ❌ Error testing wrong password: {e}")
    
    print("\n=== Authentication Flow Test Complete ===")
    print("✅ All core authentication features are working!")

if __name__ == "__main__":
    try:
        test_full_auth_flow()
    except KeyboardInterrupt:
        print("\nTest interrupted by user.")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        import traceback
        traceback.print_exc()
