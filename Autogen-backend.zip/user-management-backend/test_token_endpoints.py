import requests
import uuid

BASE_URL = "http://localhost:8000"

def get_token():
    email = f"token_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "TokenTest123!"
    signup_data = {"email": email, "username": email.split('@')[0], "password": password}
    r = requests.post(f"{BASE_URL}/auth/signup", json=signup_data)
    assert r.status_code == 201, f"Signup failed: {r.text}"
    access_token = r.json()["access_token"]
    return access_token

def test_token_endpoints():
    token = get_token()
    headers = {"Authorization": f"Bearer {token}"}
    # Test /tokens/balance
    r = requests.get(f"{BASE_URL}/tokens/balance", headers=headers)
    print("/tokens/balance:", r.status_code, r.text)
    # Test /tokens/limits
    r = requests.get(f"{BASE_URL}/tokens/limits", headers=headers)
    print("/tokens/limits:", r.status_code, r.text)
    # Test /tokens/usage
    r = requests.get(f"{BASE_URL}/tokens/usage", headers=headers)
    print("/tokens/usage:", r.status_code, r.text)
    # Test /tokens/reserve
    r = requests.post(f"{BASE_URL}/tokens/reserve", params={"amount": 100}, headers=headers)
    print("/tokens/reserve:", r.status_code, r.text)
    # Test /tokens/consume
    r = requests.post(f"{BASE_URL}/tokens/consume", params={"amount": 50, "provider": "openrouter", "model_name": "gpt-3", "request_type": "chat"}, headers=headers)
    print("/tokens/consume:", r.status_code, r.text)

if __name__ == "__main__":
    test_token_endpoints()
