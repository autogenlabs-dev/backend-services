#!/usr/bin/env python3
"""Simple API test without starting a server"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    print("Testing FastAPI application import...")
    from app.main import app
    print("Successfully imported FastAPI app")
    
    print("\nApp Information:")
    print(f"   Title: {app.title}")
    print(f"   Version: {app.version}")
    print(f"   Description: {app.description}")
    
    print("\nAvailable Routes:")
    for route in app.routes:
        if hasattr(route, 'path') and hasattr(route, 'methods'):
            methods = ', '.join(route.methods) if route.methods else 'N/A'
            print(f"   {methods:8} {route.path}")
    
    print("\nTesting Database Connection...")
    from app.database import SessionLocal, engine
    print("Database connection configured")
    
    print("\nTesting JWT functions...")
    from app.auth.jwt import create_access_token, verify_password, get_password_hash
    test_password = "test123"
    hashed = get_password_hash(test_password)
    print(f"Password hashing works: {len(hashed)} characters")
    print(f"Password verification: {verify_password(test_password, hashed)}")
    
    # Test token creation
    token = create_access_token(data={"sub": "test@example.com"})
    print(f"JWT token creation works: {token[:20]}...")
    
    print("\nTesting OAuth Configuration...")
    from app.auth.oauth import OAUTH_PROVIDERS
    print(f"OAuth providers configured: {list(OAUTH_PROVIDERS.keys())}")
    
    print("\nAll tests passed! The application is ready for API testing.")
    
except Exception as e:
    print(f"Error during testing: {e}")
    import traceback
    traceback.print_exc()
