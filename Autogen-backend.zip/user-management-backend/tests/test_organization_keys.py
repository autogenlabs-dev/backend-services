"""
Test script for organization keys functionality.
"""
import sys
import os
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.dialects.sqlite import JSON

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from app.database import Base
from app.models.user import Organization, OrganizationKey, KeyUsageLog
from app.services.organization import OrganizationService
from app.schemas.organization import OrganizationApiKeyCreate
from uuid import uuid4

@pytest.fixture(scope="module")
def setup_db():
    """Setup in-memory database for testing."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine, tables=[Organization.__table__, OrganizationKey.__table__, KeyUsageLog.__table__])
    Session = sessionmaker(bind=engine)
    return Session()

def test_create_organization_key(setup_db):
    """Test creating an organization key."""
    db = setup_db
    org_id = uuid4()
    owner_id = uuid4()  # Add a valid owner_id during organization creation
    organization = Organization(id=org_id, name="Test Org", slug=f"test-org-{uuid4()}", owner_id=owner_id)
    db.add(organization)
    db.commit()

    key_data = OrganizationApiKeyCreate(name="Test Key", permissions=["read", "write"])
    key = OrganizationService.create_organization_key(db, org_id, key_data, created_by=owner_id)

    assert key.name == "Test Key"
    assert key.permissions == ["read", "write"]
    assert key.organization_id == org_id

def test_update_organization_key(setup_db):
    """Test updating an organization key."""
    db = setup_db
    org_id = uuid4()
    owner_id = uuid4()  # Add a valid owner_id during organization creation
    organization = Organization(id=org_id, name="Test Org", slug=f"test-org-{uuid4()}", owner_id=owner_id)
    db.add(organization)
    db.commit()

    key_data = OrganizationApiKeyCreate(name="Updated Key", permissions=["read", "write"])
    key = OrganizationService.create_organization_key(db, org_id, key_data, created_by=owner_id)

    updated_data = OrganizationApiKeyCreate(name="Updated Key", permissions=["read"])
    updated_key = OrganizationService.update_organization_key(db, key.id, updated_data)

    assert updated_key.name == "Updated Key"
    assert updated_key.permissions == ["read"]

def test_delete_organization_key(setup_db):
    """Test deleting an organization key."""
    db = setup_db
    org_id = uuid4()
    owner_id = uuid4()  # Add a valid owner_id during organization creation
    organization = Organization(id=org_id, name="Test Org", slug=f"test-org-{uuid4()}", owner_id=owner_id)
    db.add(organization)
    db.commit()

    key_data = OrganizationApiKeyCreate(name="Delete Key", permissions=["read", "write"])
    key = OrganizationService.create_organization_key(db, org_id, key_data, created_by=owner_id)

    OrganizationService.delete_organization_key(db, key.id)

    deleted_key = db.query(OrganizationKey).filter_by(id=key.id).first()
    assert deleted_key is None
