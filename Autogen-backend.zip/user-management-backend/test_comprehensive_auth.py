#!/usr/bin/env python3
"""
Comprehensive authentication system verification.
Tests all implemented features and provides a summary.
"""

import requests
import json
import uuid
from datetime import datetime

BASE_URL = "http://localhost:8000"

def print_header(title):
    print("\n" + "=" * 60)
    print(f" {title}")
    print("=" * 60)

def print_step(step_num, title):
    print(f"\n🔵 STEP {step_num}: {title}")
    print("-" * 50)

def print_success(message):
    print(f"✅ {message}")

def print_error(message):
    print(f"❌ {message}")

def print_info(message):
    print(f"ℹ️  {message}")

def test_feature(feature_name, test_func):
    """Test a feature and return success status."""
    try:
        result = test_func()
        if result:
            print_success(f"{feature_name} - WORKING")
        else:
            print_error(f"{feature_name} - FAILED")
        return result
    except Exception as e:
        print_error(f"{feature_name} - ERROR: {e}")
        return False

def test_user_registration():
    """Test user registration functionality."""
    email = f"reg_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "RegTestPassword123!"
    
    response = requests.post(
        f"{BASE_URL}/auth/register",
        json={"email": email, "password": password},
        headers={"Content-Type": "application/json"}
    )
    
    if response.status_code == 200:
        user_data = response.json()
        print_info(f"Registered user: {user_data.get('email')}")
        return True
    return False

def test_user_login():
    """Test user login functionality."""
    email = f"login_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "LoginTestPassword123!"
    
    # First register
    reg_response = requests.post(
        f"{BASE_URL}/auth/register",
        json={"email": email, "password": password}
    )
    if reg_response.status_code != 200:
        return False
    
    # Then login
    login_response = requests.post(
        f"{BASE_URL}/auth/login",
        data={"username": email, "password": password}
    )
    
    if login_response.status_code == 200:
        tokens = login_response.json()
        print_info(f"Login successful, got tokens")
        return True
    return False

def test_protected_endpoints():
    """Test protected endpoint access."""
    email = f"protected_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "ProtectedTestPassword123!"
    
    # Register and login
    requests.post(f"{BASE_URL}/auth/register", json={"email": email, "password": password})
    login_response = requests.post(f"{BASE_URL}/auth/login", data={"username": email, "password": password})
    
    if login_response.status_code != 200:
        return False
    
    tokens = login_response.json()
    headers = {"Authorization": f"Bearer {tokens['access_token']}"}
    
    # Test protected endpoint
    response = requests.get(f"{BASE_URL}/users/me", headers=headers)
    
    if response.status_code == 200:
        user_data = response.json()
        print_info(f"Protected endpoint returned user: {user_data.get('email')}")
        return True
    return False

def test_token_refresh():
    """Test token refresh functionality."""
    email = f"refresh_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "RefreshTestPassword123!"
    
    # Register and login
    requests.post(f"{BASE_URL}/auth/register", json={"email": email, "password": password})
    login_response = requests.post(f"{BASE_URL}/auth/login", data={"username": email, "password": password})
    
    if login_response.status_code != 200:
        return False
    
    tokens = login_response.json()
    
    # Test refresh
    refresh_response = requests.post(
        f"{BASE_URL}/auth/refresh",
        json={"refresh_token": tokens["refresh_token"]}
    )
    
    if refresh_response.status_code == 200:
        new_tokens = refresh_response.json()
        print_info(f"Token refresh successful")
        return True
    return False

def test_oauth_providers():
    """Test OAuth providers endpoint."""
    response = requests.get(f"{BASE_URL}/auth/providers")
    
    if response.status_code == 200:
        providers = response.json()
        print_info(f"Found {len(providers.get('providers', []))} OAuth providers")
        return True
    return False

def test_security_features():
    """Test security features like duplicate registration prevention."""
    email = f"security_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "SecurityTestPassword123!"
    
    # Register user
    reg1 = requests.post(f"{BASE_URL}/auth/register", json={"email": email, "password": password})
    if reg1.status_code != 200:
        return False
    
    # Try to register again (should fail)
    reg2 = requests.post(f"{BASE_URL}/auth/register", json={"email": email, "password": password})
    
    if reg2.status_code == 400:
        print_info("Duplicate registration properly prevented")
        return True
    return False

def test_password_validation():
    """Test password validation requirements."""
    email = f"password_test_{uuid.uuid4().hex[:8]}@example.com"
    short_password = "short"
    
    response = requests.post(
        f"{BASE_URL}/auth/register",
        json={"email": email, "password": short_password}
    )
    
    if response.status_code == 422:
        print_info("Short password properly rejected")
        return True
    return False

def test_invalid_credentials():
    """Test handling of invalid credentials."""
    email = f"invalid_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "InvalidTestPassword123!"
    wrong_password = "WrongPassword123!"
    
    # Register user
    requests.post(f"{BASE_URL}/auth/register", json={"email": email, "password": password})
    
    # Try login with wrong password
    login_response = requests.post(
        f"{BASE_URL}/auth/login",
        data={"username": email, "password": wrong_password}
    )
    
    if login_response.status_code == 401:
        print_info("Wrong password properly rejected")
        return True
    return False

def main():
    print_header("COMPREHENSIVE AUTHENTICATION SYSTEM VERIFICATION")
    
    print("\n🚀 Testing all authentication features...")
    
    features = [
        ("User Registration", test_user_registration),
        ("User Login", test_user_login),
        ("Protected Endpoints", test_protected_endpoints),
        ("Token Refresh", test_token_refresh),
        ("OAuth Providers", test_oauth_providers),
        ("Security Features", test_security_features),
        ("Password Validation", test_password_validation),
        ("Invalid Credentials Handling", test_invalid_credentials),
    ]
    
    results = []
    for feature_name, test_func in features:
        success = test_feature(feature_name, test_func)
        results.append((feature_name, success))
    
    # Summary
    print_header("SUMMARY REPORT")
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    print(f"\n📊 Test Results: {passed}/{total} features working correctly")
    print("\n📋 Feature Status:")
    
    for feature_name, success in results:
        status = "✅ WORKING" if success else "❌ FAILED"
        print(f"   {feature_name:<30} {status}")
    
    if passed == total:
        print_header("🎉 ALL AUTHENTICATION FEATURES ARE WORKING!")
        print("\n✅ Your authentication system is complete and functional!")
        print("✅ Ready for production deployment!")
    else:
        print_header("⚠️  SOME FEATURES NEED ATTENTION")
        print(f"\n{total - passed} feature(s) need to be fixed.")
    
    # Database stats
    try:
        import sqlite3
        conn = sqlite3.connect('test.db')
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM users')
        user_count = cursor.fetchone()[0]
        conn.close()
        print(f"\n📈 Database Status: {user_count} users registered")
    except:
        print("\n📈 Database Status: Unable to check")
    
    print(f"\n🕒 Test completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()
