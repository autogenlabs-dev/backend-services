#!/usr/bin/env python3
"""API Testing Script for User Management Backend"""

import sys
import os
import json
import time
from datetime import datetime

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi.testclient import TestClient
from app.main import app

def test_api_endpoints():
    """Test all API endpoints"""
    print("🚀 Starting API Testing Suite...")
    print(f"📅 Test started at: {datetime.now()}")
    
    # Create test client
    client = TestClient(app)
    
    print("\n" + "="*50)
    print("1. HEALTH CHECK ENDPOINTS")
    print("="*50)
    
    # Test root endpoint
    print("🔍 Testing root endpoint...")
    response = client.get("/")
    print(f"   Status: {response.status_code}")
    print(f"   Response: {response.json()}")
    assert response.status_code == 200
    
    # Test health endpoint
    print("🔍 Testing health endpoint...")
    response = client.get("/health")
    print(f"   Status: {response.status_code}")
    print(f"   Response: {response.json()}")
    assert response.status_code == 200
    
    print("\n" + "="*50)
    print("2. AUTHENTICATION ENDPOINTS")
    print("="*50)
    
    # Test user registration
    print("🔍 Testing user registration...")
    test_user = {
        "email": "test@example.com",
        "password": "testpassword123",
        "full_name": "Test User"
    }
    
    response = client.post("/auth/register", json=test_user)
    print(f"   Status: {response.status_code}")
    if response.status_code != 200:
        print(f"   Error: {response.text}")
    else:
        print(f"   Response: {response.json()}")
    
    # Test user login
    print("🔍 Testing user login...")
    login_data = {
        "username": test_user["email"],
        "password": test_user["password"]
    }
    
    response = client.post("/auth/login", data=login_data)
    print(f"   Status: {response.status_code}")
    if response.status_code != 200:
        print(f"   Error: {response.text}")
    else:
        login_response = response.json()
        print(f"   Response: {login_response}")
        
        # Extract token for subsequent requests
        if "access_token" in login_response:
            token = login_response["access_token"]
            headers = {"Authorization": f"Bearer {token}"}
            
            print("\n" + "="*50)
            print("3. PROTECTED USER ENDPOINTS")
            print("="*50)
            
            # Test getting current user
            print("🔍 Testing get current user...")
            response = client.get("/users/me", headers=headers)
            print(f"   Status: {response.status_code}")
            if response.status_code != 200:
                print(f"   Error: {response.text}")
            else:
                print(f"   Response: {response.json()}")
            
            # Test getting user profile
            print("🔍 Testing get user profile...")
            response = client.get("/users/profile", headers=headers)
            print(f"   Status: {response.status_code}")
            if response.status_code != 200:
                print(f"   Error: {response.text}")
            else:
                print(f"   Response: {response.json()}")
    
    print("\n" + "="*50)
    print("4. OAUTH ENDPOINTS")
    print("="*50)
    
    # Test OAuth providers list
    print("🔍 Testing OAuth providers...")
    response = client.get("/auth/oauth/providers")
    print(f"   Status: {response.status_code}")
    if response.status_code != 200:
        print(f"   Error: {response.text}")
    else:
        print(f"   Response: {response.json()}")
    
    print("\n" + "="*50)
    print("✅ API TESTING COMPLETE")
    print("="*50)
    print(f"📅 Test completed at: {datetime.now()}")

if __name__ == "__main__":
    try:
        test_api_endpoints()
        print("\n🎉 All tests completed successfully!")
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
