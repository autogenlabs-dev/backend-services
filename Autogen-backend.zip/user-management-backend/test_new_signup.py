#!/usr/bin/env python3

import requests
import json
import uuid

# Test signup with a unique email
def test_signup():
    url = "http://localhost:8000/auth/signup"
    
    # Generate a unique email
    unique_email = f"testuser_{str(uuid.uuid4())[:8]}@example.com"
    
    data = {
        "username": f"testuser_{str(uuid.uuid4())[:8]}",
        "email": unique_email,
        "password": "securepassword123"
    }
    
    print(f"Testing signup with email: {unique_email}")
    try:
        response = requests.post(url, json=data, timeout=10)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code == 201:
            print("Signup successful!")
            response_data = response.json()
            print(f"User ID: {response_data.get('user', {}).get('id')}")
            print(f"Access Token: {response_data.get('access_token', 'Not provided')[:50]}...")
        else:
            print("Signup failed")
            
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")

if __name__ == "__main__":
    test_signup()
