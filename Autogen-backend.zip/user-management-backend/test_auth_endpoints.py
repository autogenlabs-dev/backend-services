#!/usr/bin/env python3
"""Test the new registration and login endpoints."""

import requests
import json

# Base URL for the API
BASE_URL = "http://127.0.0.1:8000"

def test_registration():
    """Test user registration with email and password."""
    print("=== Testing User Registration ===")
    
    # Test data
    user_data = {
        "email": "test@example.com",
        "password": "testpassword123"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/register",
            json=user_data,
            headers={"Content-Type": "application/json"}
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        
        if response.status_code == 200:
            print("✅ Registration successful!")
            return True
        else:
            print("❌ Registration failed!")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to server. Make sure it's running on port 8000.")
        return False
    except Exception as e:
        print(f"❌ Error during registration: {e}")
        return False

def test_login():
    """Test user login with email and password."""
    print("\n=== Testing User Login ===")
    
    # Test data (using form data for OAuth2PasswordRequestForm)
    login_data = {
        "username": "test@example.com",  # OAuth2PasswordRequestForm uses 'username'
        "password": "testpassword123"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/login",
            data=login_data,  # Using form data, not JSON
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        
        if response.status_code == 200:
            print("✅ Login successful!")
            token_data = response.json()
            return token_data.get("access_token")
        else:
            print("❌ Login failed!")
            return None
            
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to server. Make sure it's running on port 8000.")
        return None
    except Exception as e:
        print(f"❌ Error during login: {e}")
        return None

def test_protected_endpoint(access_token):
    """Test accessing a protected endpoint with the token."""
    print("\n=== Testing Protected Endpoint ===")
    
    try:
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(f"{BASE_URL}/auth/me", headers=headers)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        
        if response.status_code == 200:
            print("✅ Protected endpoint access successful!")
            return True
        else:
            print("❌ Protected endpoint access failed!")
            return False
            
    except Exception as e:
        print(f"❌ Error accessing protected endpoint: {e}")
        return False

def test_oauth_providers():
    """Test the OAuth providers endpoint."""
    print("\n=== Testing OAuth Providers ===")
    
    try:
        response = requests.get(f"{BASE_URL}/auth/providers")
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        
        if response.status_code == 200:
            print("✅ OAuth providers endpoint working!")
            return True
        else:
            print("❌ OAuth providers endpoint failed!")
            return False
            
    except Exception as e:
        print(f"❌ Error accessing OAuth providers: {e}")
        return False

def main():
    """Run all tests."""
    print("Starting API tests...\n")
    
    # Test OAuth providers first (doesn't require registration)
    test_oauth_providers()
    
    # Test registration
    registration_success = test_registration()
    
    if registration_success:
        # Test login
        access_token = test_login()
        
        if access_token:
            # Test protected endpoint
            test_protected_endpoint(access_token)
    
    print("\n=== Test Summary ===")
    print("Check the output above for test results.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nTest interrupted by user.")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        import traceback
        traceback.print_exc()
