#!/usr/bin/env python3
"""
Comprehensive test for complete user authentication flow.
Tests registration, login, protected endpoints, error handling, and security.
"""

import requests
import json
import uuid
from datetime import datetime

# Configuration
BASE_URL = "http://localhost:8000"
TEST_EMAIL = f"testuser_{uuid.uuid4().hex[:8]}@example.com"
TEST_PASSWORD = "TestPassword123!"

def test_complete_flow():
    print("=" * 60)
    print("TESTING COMPLETE AUTHENTICATION FLOW WITH NEW USER")
    print("=" * 60)
    print(f"Test Email: {TEST_EMAIL}")
    print(f"Test Password: {TEST_PASSWORD}")
    print(f"Base URL: {BASE_URL}")
    print()

    # Step 1: Test user registration
    print("🔵 STEP 1: Testing User Registration")
    print("-" * 40)
    
    registration_data = {
        "email": TEST_EMAIL,
        "password": TEST_PASSWORD
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/register",
            json=registration_data,
            headers={"Content-Type": "application/json"}
        )
        
        print(f"Registration Status Code: {response.status_code}")
        
        if response.status_code == 200:
            user_data = response.json()
            print("✅ Registration successful!")
            print(f"User ID: {user_data.get('id')}")
            print(f"Email: {user_data.get('email')}")
            print(f"Created At: {user_data.get('created_at')}")
            print(f"Is Active: {user_data.get('is_active')}")
            user_id = user_data.get('id')
        else:
            print("❌ Registration failed!")
            print(f"Error: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Registration request failed: {e}")
        return False
    
    print()
      # Step 2: Test user login
    print("🔵 STEP 2: Testing User Login")
    print("-" * 40)
    
    # OAuth2PasswordRequestForm expects form data with username/password
    login_data = {
        "username": TEST_EMAIL,  # OAuth2 uses 'username' field for email
        "password": TEST_PASSWORD
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/login",
            data=login_data,  # Form data, not JSON
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        print(f"Login Status Code: {response.status_code}")
        
        if response.status_code == 200:
            token_data = response.json()
            print("✅ Login successful!")
            print(f"Access Token Type: {token_data.get('token_type')}")
            print(f"Access Token (first 20 chars): {token_data.get('access_token', '')[:20]}...")
            print(f"Refresh Token (first 20 chars): {token_data.get('refresh_token', '')[:20]}...")
            access_token = token_data.get('access_token')
        else:
            print("❌ Login failed!")
            print(f"Error: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Login request failed: {e}")
        return False
    
    print()
    
    # Step 3: Test protected endpoint access
    print("🔵 STEP 3: Testing Protected Endpoint Access")
    print("-" * 40)
    
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(
            f"{BASE_URL}/users/me",
            headers=headers
        )
        
        print(f"Protected Endpoint Status Code: {response.status_code}")
        
        if response.status_code == 200:
            user_profile = response.json()
            print("✅ Protected endpoint access successful!")
            print(f"Profile User ID: {user_profile.get('id')}")
            print(f"Profile Email: {user_profile.get('email')}")
            print(f"Profile Created At: {user_profile.get('created_at')}")
            print(f"Profile Updated At: {user_profile.get('updated_at')}")
            print(f"Profile Is Active: {user_profile.get('is_active')}")
        else:
            print("❌ Protected endpoint access failed!")
            print(f"Error: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Protected endpoint request failed: {e}")
        return False
    
    print()
    
    # Step 4: Test OAuth providers endpoint
    print("🔵 STEP 4: Testing OAuth Providers Endpoint")
    print("-" * 40)
    
    try:
        response = requests.get(f"{BASE_URL}/auth/providers")
        
        print(f"OAuth Providers Status Code: {response.status_code}")
        
        if response.status_code == 200:
            providers = response.json()
            print("✅ OAuth providers endpoint successful!")
            print(f"Available providers: {len(providers.get('providers', []))}")
            for provider in providers.get('providers', []):
                print(f"  - {provider}")
        else:
            print("❌ OAuth providers endpoint failed!")
            print(f"Error: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ OAuth providers request failed: {e}")
    
    print()
    
    # Step 5: Test invalid token access
    print("🔵 STEP 5: Testing Invalid Token Access")
    print("-" * 40)
    
    invalid_headers = {
        "Authorization": "Bearer invalid_token_12345",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(
            f"{BASE_URL}/users/me",
            headers=invalid_headers
        )
        
        print(f"Invalid Token Status Code: {response.status_code}")
        
        if response.status_code == 401:
            print("✅ Invalid token properly rejected!")
            error_detail = response.json().get('detail', 'No detail provided')
            print(f"Error message: {error_detail}")
        else:
            print("❌ Invalid token was not properly rejected!")
            print(f"Unexpected response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Invalid token request failed: {e}")
    
    print()
    
    # Step 6: Test duplicate registration
    print("🔵 STEP 6: Testing Duplicate Registration Prevention")
    print("-" * 40)
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/register",
            json=registration_data,
            headers={"Content-Type": "application/json"}
        )
        
        print(f"Duplicate Registration Status Code: {response.status_code}")
        
        if response.status_code == 400:
            print("✅ Duplicate registration properly prevented!")
            error_detail = response.json().get('detail', 'No detail provided')
            print(f"Error message: {error_detail}")
        else:
            print("❌ Duplicate registration was not properly prevented!")
            print(f"Unexpected response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Duplicate registration request failed: {e}")
    
    print()
      # Step 7: Test wrong password
    print("🔵 STEP 7: Testing Wrong Password Login")
    print("-" * 40)
    
    wrong_login_data = {
        "username": TEST_EMAIL,  # OAuth2 uses 'username' field for email
        "password": "WrongPassword123!"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/login",
            data=wrong_login_data,  # Form data, not JSON
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        print(f"Wrong Password Status Code: {response.status_code}")
        
        if response.status_code == 401:
            print("✅ Wrong password properly rejected!")
            error_detail = response.json().get('detail', 'No detail provided')
            print(f"Error message: {error_detail}")
        else:
            print("❌ Wrong password was not properly rejected!")
            print(f"Unexpected response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Wrong password request failed: {e}")
    
    print()
    
    # Step 8: Test password requirements
    print("🔵 STEP 8: Testing Password Requirements")
    print("-" * 40)
    
    short_password_data = {
        "email": f"shortpass_{uuid.uuid4().hex[:6]}@example.com",
        "password": "short"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/register",
            json=short_password_data,
            headers={"Content-Type": "application/json"}
        )
        
        print(f"Short Password Status Code: {response.status_code}")
        
        if response.status_code == 422:
            print("✅ Short password properly rejected!")
            error_detail = response.json().get('detail', [])
            if error_detail:
                print(f"Validation errors: {len(error_detail)} errors found")
                for error in error_detail[:2]:  # Show first 2 errors
                    print(f"  - {error.get('msg', 'No message')}")
        else:
            print("❌ Short password was not properly rejected!")
            print(f"Unexpected response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Short password request failed: {e}")
    
    print()
    print("=" * 60)
    print("✅ COMPLETE AUTHENTICATION FLOW TEST FINISHED")
    print("=" * 60)
    return True

if __name__ == "__main__":
    success = test_complete_flow()
    if success:
        print("🎉 All tests completed successfully!")
        print("🔐 Authentication system is working correctly!")
    else:
        print("💥 Some tests failed!")
