import requests
import uuid

BASE_URL = "http://localhost:8000"

def get_token():
    email = f"llm_test_{uuid.uuid4().hex[:8]}@example.com"
    password = "LlmTest123!"
    signup_data = {"email": email, "username": email.split('@')[0], "password": password}
    r = requests.post(f"{BASE_URL}/auth/signup", json=signup_data)
    assert r.status_code == 201, f"Signup failed: {r.text}"
    access_token = r.json()["access_token"]
    return access_token

def test_llm_endpoints():
    token = get_token()
    headers = {"Authorization": f"Bearer {token}"}
    # Test /llm/models
    r = requests.get(f"{BASE_URL}/llm/models", headers=headers)
    print("/llm/models:", r.status_code, r.text)
    # Test /llm/providers
    r = requests.get(f"{BASE_URL}/llm/providers", headers=headers)
    print("/llm/providers:", r.status_code, r.text)
    # Test /llm/chat/completions
    r = requests.post(f"{BASE_URL}/llm/chat/completions", headers=headers)
    print("/llm/chat/completions:", r.status_code, r.text)
    # Test /llm/completions
    r = requests.post(f"{BASE_URL}/llm/completions", headers=headers)
    print("/llm/completions:", r.status_code, r.text)
    # Test /llm/embeddings
    r = requests.post(f"{BASE_URL}/llm/embeddings", headers=headers)
    print("/llm/embeddings:", r.status_code, r.text)

if __name__ == "__main__":
    test_llm_endpoints()
