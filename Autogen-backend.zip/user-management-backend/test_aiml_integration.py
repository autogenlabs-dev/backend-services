#!/usr/bin/env python3
"""Test AIML integration."""

import sys
import os
sys.path.append(os.path.dirname(__file__))

def test_aiml_integration():
    """Test AIML integration."""
    try:
        # Test config
        from app.config import settings
        print("✅ Config imported successfully")
        
        # Check AIML settings
        aiml_attrs = [attr for attr in dir(settings) if 'aiml' in attr.lower()]
        print(f"AIML config attributes: {aiml_attrs}")
        
        # Test AIML client import
        from app.services.llm_proxy_service import AIMLClient
        print("✅ AIML Client imported successfully")
        
        # Test instantiation
        client = AIMLClient()
        print(f"✅ AIML Client created with base URL: {client.base_url}")
        
        # Test LLM proxy service
        from app.services.llm_proxy_service import LLMProxyService
        from app.database import SessionLocal
        
        db = SessionLocal()
        proxy = LLMProxyService(db)
        print(f"✅ LLM Proxy Service created with providers: {list(proxy.providers.keys())}")
        
        # Test model routing
        provider_name, provider_client = proxy.get_provider_from_model("aiml/gpt-4")
        print(f"✅ Model routing works: aiml/gpt-4 -> {provider_name}")
        
        print("\n🎉 All AIML integration tests passed!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if 'db' in locals():
            db.close()

if __name__ == "__main__":
    test_aiml_integration()
