#!/usr/bin/env python3
"""
Test script for database models
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from app.database import Base
    print("Database Base imported successfully")
    
    from app.models.user import User, OAuthProvider, UserOAuthAccount
    print("User models imported successfully")
    
    from app.models.user import SubscriptionPlan, UserSubscription
    print("Subscription models imported successfully")
    
    from app.models.user import TokenUsageLog, ApiKey
    print("Token and API models imported successfully")
    
    # Test creating the tables in memory
    from sqlalchemy import create_engine
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    print("All database tables created successfully in memory")
    
    # Print table names
    print(f"\nCreated tables: {list(Base.metadata.tables.keys())}")
    
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
