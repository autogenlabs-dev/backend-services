#!/usr/bin/env python3
"""
Comprehensive test for the full authentication flow:
1. Signup with new user
2. Login with created user 
3. Access protected endpoint with token
4. Refresh token
5. Test error cases
"""

import requests
import json
import uuid
import time

BASE_URL = "http://localhost:8000"

def test_full_auth_flow():
    """Test the complete authentication flow."""
    print("🧪 Starting comprehensive authentication flow test...\n")
    
    # Generate unique test data
    test_id = str(uuid.uuid4())[:8]
    test_email = f"testuser_{test_id}@example.com"
    test_username = f"testuser_{test_id}"
    test_password = "SecurePassword123!"
    
    print(f"📝 Test user details:")
    print(f"   Email: {test_email}")
    print(f"   Username: {test_username}")
    print(f"   Password: {test_password}\n")
    
    # Step 1: Test Signup
    print("1️⃣ Testing user signup...")
    signup_data = {
        "email": test_email,
        "username": test_username,
        "password": test_password,
        "name": f"Test User {test_id}",
        "full_name": f"Test User Full Name {test_id}"
    }
    
    try:
        signup_response = requests.post(f"{BASE_URL}/auth/signup", json=signup_data, timeout=10)
        print(f"   Status Code: {signup_response.status_code}")
        
        if signup_response.status_code == 201:
            signup_result = signup_response.json()
            print("   ✅ Signup successful!")
            print(f"   User ID: {signup_result.get('user', {}).get('id')}")
            print(f"   Access Token: {signup_result.get('access_token', 'Not provided')[:50]}...")
            
            # Save tokens for later use
            access_token = signup_result.get('access_token')
            refresh_token = signup_result.get('refresh_token')
            user_id = signup_result.get('user', {}).get('id')
            
        else:
            print(f"   ❌ Signup failed: {signup_response.text}")
            return False
            
    except Exception as e:
        print(f"   ❌ Signup request failed: {e}")
        return False
    
    print()
      # Step 2: Test Login
    print("2️⃣ Testing user login...")
    login_data = {
        "email": test_email,
        "password": test_password
    }
    
    try:
        login_response = requests.post(f"{BASE_URL}/auth/login-json", json=login_data, timeout=10)
        print(f"   Status Code: {login_response.status_code}")
        
        if login_response.status_code == 200:
            login_result = login_response.json()
            print("   ✅ Login successful!")
            print(f"   Access Token: {login_result.get('access_token', 'Not provided')[:50]}...")
            print(f"   Refresh Token: {login_result.get('refresh_token', 'Not provided')[:50]}...")
            
            # Update tokens
            access_token = login_result.get('access_token')
            refresh_token = login_result.get('refresh_token')
            
        else:
            print(f"   ❌ Login failed: {login_response.text}")
            return False
            
    except Exception as e:
        print(f"   ❌ Login request failed: {e}")
        return False
    
    print()
    
    # Step 3: Test protected endpoint
    print("3️⃣ Testing protected endpoint access...")
    headers = {"Authorization": f"Bearer {access_token}"}
    
    try:
        profile_response = requests.get(f"{BASE_URL}/users/me", headers=headers, timeout=10)
        print(f"   Status Code: {profile_response.status_code}")
        
        if profile_response.status_code == 200:
            profile_result = profile_response.json()
            print("   Protected endpoint access successful!")
            print(f"   User Email: {profile_result.get('email')}")
            print(f"   User Name: {profile_result.get('name', profile_result.get('full_name', ''))}")
            
        else:
            print(f"   ❌ Protected endpoint access failed: {profile_response.text}")
            return False
            
    except Exception as e:
        print(f"   ❌ Protected endpoint request failed: {e}")
        return False
    
    print()
    
    # Step 4: Test token refresh
    print("4️⃣ Testing token refresh...")
    refresh_data = {"refresh_token": refresh_token}
    
    try:
        refresh_response = requests.post(f"{BASE_URL}/auth/refresh", json=refresh_data, timeout=10)
        print(f"   Status Code: {refresh_response.status_code}")
        
        if refresh_response.status_code == 200:
            refresh_result = refresh_response.json()
            print("   ✅ Token refresh successful!")
            print(f"   New Access Token: {refresh_result.get('access_token', 'Not provided')[:50]}...")
            
        else:
            print(f"   ❌ Token refresh failed: {refresh_response.text}")
            return False
            
    except Exception as e:
        print(f"   ❌ Token refresh request failed: {e}")
        return False
    
    print()
    
    # Step 5: Test error cases
    print("5️⃣ Testing error cases...")
    
    # Test duplicate signup
    print("   Testing duplicate signup...")
    try:
        duplicate_response = requests.post(f"{BASE_URL}/auth/signup", json=signup_data, timeout=10)
        if duplicate_response.status_code == 400:
            print("   ✅ Duplicate signup correctly rejected")
        else:
            print(f"   ❌ Unexpected duplicate signup response: {duplicate_response.status_code}")
    except Exception as e:
        print(f"   ❌ Duplicate signup test failed: {e}")
    
    # Test invalid login
    print("   Testing invalid login...")
    invalid_login_data = {
        "email": test_email,
        "password": "WrongPassword123!"
    }
    try:
        invalid_login_response = requests.post(f"{BASE_URL}/auth/login", json=invalid_login_data, timeout=10)
        if invalid_login_response.status_code == 401:
            print("   ✅ Invalid login correctly rejected")
        else:
            print(f"   ❌ Unexpected invalid login response: {invalid_login_response.status_code}")
    except Exception as e:
        print(f"   ❌ Invalid login test failed: {e}")
    
    # Test invalid token
    print("   Testing invalid token...")
    invalid_headers = {"Authorization": "Bearer invalid_token_here"}
    try:
        invalid_token_response = requests.get(f"{BASE_URL}/auth/profile", headers=invalid_headers, timeout=10)
        if invalid_token_response.status_code == 401:
            print("   ✅ Invalid token correctly rejected")
        else:
            print(f"   ❌ Unexpected invalid token response: {invalid_token_response.status_code}")
    except Exception as e:
        print(f"   ❌ Invalid token test failed: {e}")
    
    print()
    print("🎉 All authentication flow tests completed successfully!")
    return True

def test_server_health():
    """Test if server is responding."""
    print("🏥 Testing server health...")
    try:
        health_response = requests.get(f"{BASE_URL}/", timeout=5)
        if health_response.status_code == 200:
            print("   ✅ Server is healthy and responding")
            return True
        else:
            print(f"   ❌ Server health check failed: {health_response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Server health check failed: {e}")
        return False

if __name__ == "__main__":
    print("🚀 Starting comprehensive authentication tests...\n")
    
    # Test server health first
    if not test_server_health():
        print("❌ Server is not responding. Please start the server first.")
        exit(1)
    
    print()
    
    # Run full authentication flow test
    success = test_full_auth_flow()
    
    if success:
        print("\n🎊 All tests passed! Authentication system is working correctly.")
        exit(0)
    else:
        print("\n💥 Some tests failed. Please check the server logs for details.")
        exit(1)
