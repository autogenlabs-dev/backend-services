#!/usr/bin/env python3
"""
Test token refresh functionality.
"""

import requests
import json
import uuid
import time

# Configuration
BASE_URL = "http://localhost:8000"
TEST_EMAIL = f"refresh_test_{uuid.uuid4().hex[:8]}@example.com"
TEST_PASSWORD = "RefreshTestPassword123!"

def test_token_refresh():
    print("=" * 60)
    print("TESTING TOKEN REFRESH FUNCTIONALITY")
    print("=" * 60)
    print(f"Test Email: {TEST_EMAIL}")
    print(f"Base URL: {BASE_URL}")
    print()

    # Step 1: Register a new user
    print("🔵 STEP 1: Registering Test User")
    print("-" * 40)
    
    registration_data = {
        "email": TEST_EMAIL,
        "password": TEST_PASSWORD
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/register",
            json=registration_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code != 200:
            print(f"❌ Registration failed: {response.text}")
            return False
            
        print("✅ User registered successfully!")
        
    except Exception as e:
        print(f"❌ Registration failed: {e}")
        return False

    # Step 2: Login to get initial tokens
    print("\n🔵 STEP 2: Login to Get Initial Tokens")
    print("-" * 40)
    
    login_data = {
        "username": TEST_EMAIL,
        "password": TEST_PASSWORD
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/login",
            data=login_data,
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        if response.status_code != 200:
            print(f"❌ Login failed: {response.text}")
            return False
            
        token_data = response.json()
        original_access_token = token_data.get('access_token')
        refresh_token = token_data.get('refresh_token')
        
        print("✅ Login successful!")
        print(f"Original Access Token (first 20 chars): {original_access_token[:20]}...")
        print(f"Refresh Token (first 20 chars): {refresh_token[:20]}...")
        
    except Exception as e:
        print(f"❌ Login failed: {e}")
        return False

    # Step 3: Test access with original token
    print("\n🔵 STEP 3: Testing Original Access Token")
    print("-" * 40)
    
    headers = {
        "Authorization": f"Bearer {original_access_token}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/users/me", headers=headers)
        
        if response.status_code != 200:
            print(f"❌ Original token access failed: {response.text}")
            return False
            
        user_data = response.json()
        print("✅ Original access token works!")
        print(f"User Email: {user_data.get('email')}")
        
    except Exception as e:
        print(f"❌ Original token test failed: {e}")
        return False

    # Step 4: Use refresh token to get new access token
    print("\n🔵 STEP 4: Refreshing Access Token")
    print("-" * 40)
    
    refresh_data = {
        "refresh_token": refresh_token
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/refresh",
            json=refresh_data,
            headers={"Content-Type": "application/json"}
        )
        
        print(f"Refresh Status Code: {response.status_code}")
        
        if response.status_code != 200:
            print(f"❌ Token refresh failed: {response.text}")
            return False
            
        new_token_data = response.json()
        new_access_token = new_token_data.get('access_token')
        new_refresh_token = new_token_data.get('refresh_token')
        
        print("✅ Token refresh successful!")
        print(f"New Access Token (first 20 chars): {new_access_token[:20]}...")
        print(f"New Refresh Token (first 20 chars): {new_refresh_token[:20]}...")
        
        # Verify tokens are different
        if new_access_token != original_access_token:
            print("✅ New access token is different from original!")
        else:
            print("⚠️  New access token is the same as original (unexpected)")
            
    except Exception as e:
        print(f"❌ Token refresh failed: {e}")
        return False

    # Step 5: Test access with new token
    print("\n🔵 STEP 5: Testing New Access Token")
    print("-" * 40)
    
    new_headers = {
        "Authorization": f"Bearer {new_access_token}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/users/me", headers=new_headers)
        
        if response.status_code != 200:
            print(f"❌ New token access failed: {response.text}")
            return False
            
        user_data = response.json()
        print("✅ New access token works!")
        print(f"User Email: {user_data.get('email')}")
        
    except Exception as e:
        print(f"❌ New token test failed: {e}")
        return False

    # Step 6: Test invalid refresh token
    print("\n🔵 STEP 6: Testing Invalid Refresh Token")
    print("-" * 40)
    
    invalid_refresh_data = {
        "refresh_token": "invalid_refresh_token_12345"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/auth/refresh",
            json=invalid_refresh_data,
            headers={"Content-Type": "application/json"}
        )
        
        print(f"Invalid Refresh Status Code: {response.status_code}")
        
        if response.status_code == 401:
            print("✅ Invalid refresh token properly rejected!")
            error_detail = response.json().get('detail', 'No detail provided')
            print(f"Error message: {error_detail}")
        else:
            print("❌ Invalid refresh token was not properly rejected!")
            print(f"Unexpected response: {response.text}")
            
    except Exception as e:
        print(f"❌ Invalid refresh token test failed: {e}")

    print("\n" + "=" * 60)
    print("✅ TOKEN REFRESH FUNCTIONALITY TEST FINISHED")
    print("=" * 60)
    return True

if __name__ == "__main__":
    success = test_token_refresh()
    if success:
        print("🎉 Token refresh functionality works correctly!")
    else:
        print("💥 Token refresh test failed!")
