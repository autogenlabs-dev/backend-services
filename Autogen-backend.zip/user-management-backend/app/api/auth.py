"""Authentication API endpoints."""

from datetime import timedelta
from typing import Dict, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas.auth import Token, TokenRefresh, OAuthCallback, UserCreate, UserLogin, UserResponse
from ..auth.jwt import create_access_token, create_refresh_token, verify_token
from ..auth.oauth import get_oauth_client, get_provider_config, oauth
from ..auth.dependencies import get_current_user
from ..services.user_service import (
    get_or_create_user_by_oauth, 
    update_user_last_login, 
    create_user_with_password,
    authenticate_user
)
from ..config import settings

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.get("/providers")
async def list_oauth_providers() -> Dict[str, Any]:
    """List available OAuth providers."""
    from ..auth.oauth import OAUTH_PROVIDERS
    
    providers = []
    for name, config in OAUTH_PROVIDERS.items():
        if config["client_id"] and config["client_secret"]:        providers.append({
                "name": name,
                "display_name": config["display_name"],
                "authorization_url": f"/auth/{name}/login"
            })
    return {"providers": providers}


@router.post("/register", response_model=UserResponse)
async def register_user(user_data: UserCreate, db: Session = Depends(get_db)):
    """Register a new user with email and password."""
    try:
        user = create_user_with_password(db, user_data)
        return UserResponse(
            id=user.id,
            email=user.email,
            is_active=user.is_active,
            created_at=user.created_at,
            updated_at=user.updated_at,
            last_login_at=user.last_login_at
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        # Log the actual error for debugging
        import traceback
        print(f"Registration error: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create user: {str(e)}"
        )


@router.post("/signup", status_code=status.HTTP_201_CREATED)
async def signup_user(user_data: UserCreate, db: Session = Depends(get_db)):
    """Alias for user registration to support /signup route with token generation."""
    try:
        # Register the user
        user = await register_user(user_data, db)
        
        # Generate tokens
        access_token = create_access_token(data={"sub": str(user.id)})
        refresh_token = create_refresh_token(data={"sub": str(user.id)})
        
        # Return user data and tokens
        return {
            "user": user,
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer"
        }
    except Exception as e:
        import traceback
        print(f"Error in signup: {str(e)}")
        print(traceback.format_exc())
        raise


@router.post("/login", response_model=Token)
async def login_user(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """Login user with email and password."""
    user = authenticate_user(db, form_data.username, form_data.password)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is disabled"
        )
    
    # Update last login
    update_user_last_login(db, user.id)
    
    # Create tokens
    access_token = create_access_token(
        data={"sub": str(user.id), "email": user.email},
        expires_delta=timedelta(minutes=settings.access_token_expire_minutes)
    )
    refresh_token = create_refresh_token(
        data={"sub": str(user.id)}
    )
    
    return Token(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer"
    )
        
@router.post("/login-json", response_model=Token)
async def login_user_json(
    user_data: UserLogin,
    db: Session = Depends(get_db)
):
    """Login user with email and password using JSON."""
    user = authenticate_user(db, user_data.email, user_data.password)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is disabled"
        )
      # Update last login
    update_user_last_login(db, user.id)
    
    # Create tokens
    access_token = create_access_token(
        data={"sub": str(user.id), "email": user.email},
        expires_delta=timedelta(minutes=settings.access_token_expire_minutes)
    )
    refresh_token = create_refresh_token(
        data={"sub": str(user.id)}
    )
    
    return Token(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer"
    )


@router.get("/{provider}/login")
async def oauth_login(provider: str, request: Request):
    """Initiate OAuth login with a provider."""
    if provider not in ["openrouter", "glama", "requesty", "aiml"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid OAuth provider"
        )
    
    config = get_provider_config(provider)
    if not config or not config.get("client_id"):
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=f"OAuth provider {provider} is not configured"
        )
    
    try:
        client = oauth.create_client(provider)
        redirect_uri = str(request.url_for("oauth_callback", provider=provider))
        
        return await client.authorize_redirect(request, redirect_uri)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to initiate OAuth login: {str(e)}"
        )


@router.get("/{provider}/callback")
async def oauth_callback(
    provider: str, 
    request: Request,
    db: Session = Depends(get_db)
) -> Token:
    """Handle OAuth callback and create user session."""
    if provider not in ["openrouter", "glama", "requesty"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid OAuth provider"
        )
    
    try:
        client = oauth.create_client(provider)
        token = await client.authorize_access_token(request)
        
        # Get user info from provider
        config = get_provider_config(provider)
        userinfo_endpoint = config.get("userinfo_endpoint")
        
        if userinfo_endpoint:
            # Use the token to get user info
            user_info = await client.get(userinfo_endpoint, token=token)
            user_data = user_info.json()
        else:
            # Use the token directly if it contains user info
            user_data = token.get("userinfo", {})
        
        # Extract user information
        email = user_data.get("email")
        provider_user_id = user_data.get("id") or user_data.get("sub")
        
        if not email or not provider_user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Could not extract user information from OAuth provider"
            )
        
        # Get or create user
        user = get_or_create_user_by_oauth(
            db=db,
            provider_name=provider,
            provider_user_id=str(provider_user_id),
            email=email
        )
        
        # Update last login
        update_user_last_login(db, user.id)
        
        # Create tokens
        access_token = create_access_token(
            data={"sub": str(user.id), "email": user.email},
            expires_delta=timedelta(minutes=settings.access_token_expire_minutes)
        )
        refresh_token = create_refresh_token(
            data={"sub": str(user.id)}
        )
        
        return Token(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"OAuth callback failed: {str(e)}"
        )


@router.post("/refresh")
async def refresh_access_token(
    token_data: TokenRefresh,
    db: Session = Depends(get_db)
) -> Token:
    """Refresh an access token using a refresh token."""
    payload = verify_token(token_data.refresh_token)
    
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    # Verify user still exists and is active
    from ..services.user_service import get_user_by_id
    user = get_user_by_id(db, UUID(user_id))
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive"
        )
    
    # Create new tokens
    access_token = create_access_token(
        data={"sub": str(user.id), "email": user.email}
    )
    refresh_token = create_refresh_token(
        data={"sub": str(user.id)}
    )
    
    return Token(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer"
    )


@router.post("/logout")
async def logout(current_user = Depends(get_current_user)):
    """Logout the current user."""
    # In a production system, you might want to blacklist the token
    # For now, we'll just return a success message
    return {"message": "Successfully logged out"}


@router.get("/me")
async def get_current_user_info(current_user = Depends(get_current_user)):
    """Get current user information."""
    return {
        "id": current_user.id,
        "email": current_user.email,
        "is_active": current_user.is_active,
        "created_at": current_user.created_at,
        "last_login_at": current_user.last_login_at
    }
