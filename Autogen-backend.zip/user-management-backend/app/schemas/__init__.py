# Pydantic schemas
