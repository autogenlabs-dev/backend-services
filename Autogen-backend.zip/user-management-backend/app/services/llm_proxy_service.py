"""LLM proxy service for token-gated provider access."""

import httpx
import json
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple
from decimal import Decimal
from sqlalchemy.orm import Session

from ..config import settings
from ..models.user import User, TokenUsageLog
from .token_service import TokenService, TokenPricingService


class LLMProviderClient:
    """Base class for LLM provider clients."""
    
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url
        self.api_key = api_key
        self.client = httpx.AsyncClient(timeout=30.0)
    
    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List available models from the provider."""
        raise NotImplementedError
    
    async def chat_completion(self, messages: List[Dict[str, Any]], model: str, **kwargs) -> Dict[str, Any]:
        """Create a chat completion."""
        raise NotImplementedError
    
    async def text_completion(self, prompt: str, model: str, **kwargs) -> Dict[str, Any]:
        """Create a text completion."""
        raise NotImplementedError
    
    async def embeddings(self, input_text: str, model: str, **kwargs) -> Dict[str, Any]:
        """Create embeddings."""
        raise NotImplementedError


class OpenRouterClient(LLMProviderClient):
    """OpenRouter API client."""
    
    def __init__(self):
        super().__init__(
            base_url="https://openrouter.ai/api/v1",
            api_key=settings.openrouter_api_key
        )
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List OpenRouter models."""
        try:
            response = await self.client.get(
                f"{self.base_url}/models",
                headers={"Authorization": f"Bearer {self.api_key}"}
            )
            response.raise_for_status()
            data = response.json()
            
            return [{
                "id": model["id"],
                "name": model["name"],
                "provider": "openrouter",
                "context_length": model.get("context_length", 4096),
                "pricing": model.get("pricing", {}),
                "description": model.get("description", "")
            } for model in data.get("data", [])]
            
        except Exception as e:
            return [{"error": f"Failed to fetch OpenRouter models: {str(e)}"}]
    
    async def chat_completion(self, messages: List[Dict[str, Any]], model: str, **kwargs) -> Dict[str, Any]:
        """Create OpenRouter chat completion."""
        try:
            payload = {
                "model": model,
                "messages": messages,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"OpenRouter chat completion failed: {str(e)}"}
    
    async def text_completion(self, prompt: str, model: str, **kwargs) -> Dict[str, Any]:
        """Create OpenRouter text completion."""
        try:
            payload = {
                "model": model,
                "prompt": prompt,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"OpenRouter completion failed: {str(e)}"}
    
    async def embeddings(self, input_text: str, model: str, **kwargs) -> Dict[str, Any]:
        """Create OpenRouter embeddings."""
        try:
            payload = {
                "model": model,
                "input": input_text,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/embeddings",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"OpenRouter embeddings failed: {str(e)}"}


class GlamaClient(LLMProviderClient):
    """Glama API client."""
    
    def __init__(self):
        super().__init__(
            base_url="https://api.glama.ai/v1",
            api_key=settings.glama_api_key
        )
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List Glama models."""
        try:
            response = await self.client.get(
                f"{self.base_url}/models",
                headers={"Authorization": f"Bearer {self.api_key}"}
            )
            response.raise_for_status()
            data = response.json()
            
            return [{
                "id": model["id"],
                "name": model.get("name", model["id"]),
                "provider": "glama",
                "context_length": model.get("context_length", 4096),
                "description": model.get("description", "")
            } for model in data.get("data", [])]
            
        except Exception as e:
            return [{"error": f"Failed to fetch Glama models: {str(e)}"}]
    
    async def chat_completion(self, messages: List[Dict[str, Any]], model: str, **kwargs) -> Dict[str, Any]:
        """Create Glama chat completion."""
        try:
            payload = {
                "model": model,
                "messages": messages,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"Glama chat completion failed: {str(e)}"}


class RequestyClient(LLMProviderClient):
    """Requesty API client."""
    
    def __init__(self):
        super().__init__(
            base_url="https://api.requesty.ai/v1",
            api_key=settings.requesty_api_key
        )
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List Requesty models."""
        try:
            response = await self.client.get(
                f"{self.base_url}/models",
                headers={"Authorization": f"Bearer {self.api_key}"}
            )
            response.raise_for_status()
            data = response.json()
            
            return [{
                "id": model["id"],
                "name": model.get("name", model["id"]),
                "provider": "requesty",
                "context_length": model.get("context_length", 4096),
                "description": model.get("description", "")
            } for model in data.get("data", [])]
            
        except Exception as e:
            return [{"error": f"Failed to fetch Requesty models: {str(e)}"}]
    
    async def chat_completion(self, messages: List[Dict[str, Any]], model: str, **kwargs) -> Dict[str, Any]:
        """Create Requesty chat completion."""
        try:
            payload = {
                "model": model,
                "messages": messages,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"Requesty chat completion failed: {str(e)}"}


class AIMLClient(LLMProviderClient):
    """AIML API client."""
    
    def __init__(self):
        super().__init__(
            base_url="https://api.aimlapi.com/v1",
            api_key=settings.aiml_api_key
        )
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List AIML models."""
        try:
            response = await self.client.get(
                f"{self.base_url}/models",
                headers={"Authorization": f"Bearer {self.api_key}"}
            )
            response.raise_for_status()
            data = response.json()
            
            return [{
                "id": model["id"],
                "name": model.get("name", model["id"]),
                "provider": "aiml",
                "context_length": model.get("context_length", 4096),
                "description": model.get("description", "")
            } for model in data.get("data", [])]
            
        except Exception as e:
            return [{"error": f"Failed to fetch AIML models: {str(e)}"}]
    
    async def chat_completion(self, messages: List[Dict[str, Any]], model: str, **kwargs) -> Dict[str, Any]:
        """Create AIML chat completion."""
        try:
            payload = {
                "model": model,
                "messages": messages,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"AIML chat completion failed: {str(e)}"}
    
    async def text_completion(self, prompt: str, model: str, **kwargs) -> Dict[str, Any]:
        """Create AIML text completion."""
        try:
            payload = {
                "model": model,
                "prompt": prompt,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"AIML completion failed: {str(e)}"}
    
    async def embeddings(self, input_text: str, model: str, **kwargs) -> Dict[str, Any]:
        """Create AIML embeddings."""
        try:
            payload = {
                "model": model,
                "input": input_text,
                **kwargs
            }
            
            response = await self.client.post(
                f"{self.base_url}/embeddings",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            return {"error": f"AIML embeddings failed: {str(e)}"}


class LLMProxyService:
    """Service for proxying LLM requests with token management."""
    
    def __init__(self, db: Session):
        self.db = db
        self.token_service = TokenService(db)
        self.pricing_service = TokenPricingService()
        
        # Initialize provider clients
        self.providers = {
            "openrouter": OpenRouterClient(),
            "glama": GlamaClient(),
            "requesty": RequestyClient(),
            "aiml": AIMLClient()
        }
    
    async def close(self):
        """Close all provider clients."""
        for provider in self.providers.values():
            await provider.close()
    
    def get_provider_from_model(self, model: str) -> Tuple[str, LLMProviderClient]:
        """Determine provider from model name."""
        # Simple routing logic - could be more sophisticated
        if "openrouter" in model.lower() or model.startswith("or/"):
            return "openrouter", self.providers["openrouter"]
        elif "glama" in model.lower() or model.startswith("glama/"):
            return "glama", self.providers["glama"]
        elif "requesty" in model.lower() or model.startswith("req/"):
            return "requesty", self.providers["requesty"]
        elif "aiml" in model.lower() or model.startswith("aiml/"):
            return "aiml", self.providers["aiml"]
        else:
            # Default to OpenRouter for unknown models
            return "openrouter", self.providers["openrouter"]
    
    async def list_all_models(self) -> Dict[str, Any]:
        """List models from all providers."""
        all_models = []
        provider_status = {}
        
        for provider_name, client in self.providers.items():
            try:
                models = await client.list_models()
                all_models.extend(models)
                provider_status[provider_name] = "available"
            except Exception as e:
                provider_status[provider_name] = f"error: {str(e)}"
        
        return {
            "models": all_models,
            "provider_status": provider_status,
            "total_models": len(all_models)
        }
    
    async def estimate_tokens(self, text: str, model: str) -> int:
        """Estimate token count for text (rough approximation)."""
        # Simple approximation: ~4 characters per token
        return max(1, len(text) // 4)
    
    async def chat_completion(self, user: User, messages: List[Dict[str, Any]], model: str, **kwargs) -> Dict[str, Any]:
        """Process chat completion with token management."""
        try:
            # Estimate tokens needed
            total_text = " ".join([msg.get("content", "") for msg in messages])
            estimated_tokens = await self.estimate_tokens(total_text, model)
            
            # Check if user has sufficient tokens
            if not self.token_service.can_use_tokens(user, estimated_tokens):
                return {
                    "error": "Insufficient tokens",
                    "details": "Your current plan doesn't have enough tokens for this request",
                    "required_tokens": estimated_tokens,
                    "available_tokens": self.token_service.get_available_tokens(user)
                }
            
            # Reserve tokens
            reservation_id = self.token_service.reserve_tokens(user, estimated_tokens, "chat_completion", {
                "model": model,
                "message_count": len(messages)
            })
            
            try:
                # Route to appropriate provider
                provider_name, provider_client = self.get_provider_from_model(model)
                
                # Make the API call
                response = await provider_client.chat_completion(messages, model, **kwargs)
                
                if "error" in response:
                    # Release reserved tokens on error
                    self.token_service.release_reserved_tokens(reservation_id)
                    return response
                
                # Calculate actual tokens used
                actual_tokens = response.get("usage", {}).get("total_tokens", estimated_tokens)
                cost = self.pricing_service.calculate_cost(provider_name, model, actual_tokens, "chat")
                
                # Consume tokens and log usage
                self.token_service.consume_reserved_tokens(
                    reservation_id=reservation_id,
                    actual_tokens=actual_tokens,
                    cost_usd=cost,
                    response_metadata={
                        "completion_tokens": response.get("usage", {}).get("completion_tokens", 0),
                        "prompt_tokens": response.get("usage", {}).get("prompt_tokens", 0)
                    }
                )
                
                # Add usage info to response
                response["_usage_info"] = {
                    "tokens_used": actual_tokens,
                    "cost_usd": float(cost),
                    "provider": provider_name,
                    "remaining_tokens": self.token_service.get_available_tokens(user)
                }
                
                return response
                
            except Exception as e:
                # Release reserved tokens on error
                self.token_service.release_reserved_tokens(reservation_id)
                return {"error": f"Request failed: {str(e)}"}
        
        except Exception as e:
            return {"error": f"Token management error: {str(e)}"}
    
    async def text_completion(self, user: User, prompt: str, model: str, **kwargs) -> Dict[str, Any]:
        """Process text completion with token management."""
        try:
            # Estimate tokens needed
            estimated_tokens = await self.estimate_tokens(prompt, model)
            
            # Check if user has sufficient tokens
            if not self.token_service.can_use_tokens(user, estimated_tokens):
                return {
                    "error": "Insufficient tokens",
                    "details": "Your current plan doesn't have enough tokens for this request",
                    "required_tokens": estimated_tokens,
                    "available_tokens": self.token_service.get_available_tokens(user)
                }
            
            # Reserve tokens
            reservation_id = self.token_service.reserve_tokens(user, estimated_tokens, "text_completion", {
                "model": model,
                "prompt_length": len(prompt)
            })
            
            try:
                # Route to appropriate provider
                provider_name, provider_client = self.get_provider_from_model(model)
                
                # Make the API call
                response = await provider_client.text_completion(prompt, model, **kwargs)
                
                if "error" in response:
                    # Release reserved tokens on error
                    self.token_service.release_reserved_tokens(reservation_id)
                    return response
                
                # Calculate actual tokens used
                actual_tokens = response.get("usage", {}).get("total_tokens", estimated_tokens)
                cost = self.pricing_service.calculate_cost(provider_name, model, actual_tokens, "completion")
                
                # Consume tokens and log usage
                self.token_service.consume_reserved_tokens(
                    reservation_id=reservation_id,
                    actual_tokens=actual_tokens,
                    cost_usd=cost,
                    response_metadata=response.get("usage", {})
                )
                
                # Add usage info to response
                response["_usage_info"] = {
                    "tokens_used": actual_tokens,
                    "cost_usd": float(cost),
                    "provider": provider_name,
                    "remaining_tokens": self.token_service.get_available_tokens(user)
                }
                
                return response
                
            except Exception as e:
                # Release reserved tokens on error
                self.token_service.release_reserved_tokens(reservation_id)
                return {"error": f"Request failed: {str(e)}"}
        
        except Exception as e:
            return {"error": f"Token management error: {str(e)}"}
    
    async def embeddings(self, user: User, input_text: str, model: str, **kwargs) -> Dict[str, Any]:
        """Process embeddings with token management."""
        try:
            # Estimate tokens needed (embeddings typically use input tokens only)
            estimated_tokens = await self.estimate_tokens(input_text, model)
            
            # Check if user has sufficient tokens
            if not self.token_service.can_use_tokens(user, estimated_tokens):
                return {
                    "error": "Insufficient tokens",
                    "details": "Your current plan doesn't have enough tokens for this request",
                    "required_tokens": estimated_tokens,
                    "available_tokens": self.token_service.get_available_tokens(user)
                }
            
            # Reserve tokens
            reservation_id = self.token_service.reserve_tokens(user, estimated_tokens, "embeddings", {
                "model": model,
                "input_length": len(input_text)
            })
            
            try:
                # Route to appropriate provider
                provider_name, provider_client = self.get_provider_from_model(model)
                
                # Make the API call
                response = await provider_client.embeddings(input_text, model, **kwargs)
                
                if "error" in response:
                    # Release reserved tokens on error
                    self.token_service.release_reserved_tokens(reservation_id)
                    return response
                
                # Calculate actual tokens used
                actual_tokens = response.get("usage", {}).get("total_tokens", estimated_tokens)
                cost = self.pricing_service.calculate_cost(provider_name, model, actual_tokens, "embeddings")
                
                # Consume tokens and log usage
                self.token_service.consume_reserved_tokens(
                    reservation_id=reservation_id,
                    actual_tokens=actual_tokens,
                    cost_usd=cost,
                    response_metadata=response.get("usage", {})
                )
                
                # Add usage info to response
                response["_usage_info"] = {
                    "tokens_used": actual_tokens,
                    "cost_usd": float(cost),
                    "provider": provider_name,
                    "remaining_tokens": self.token_service.get_available_tokens(user)
                }
                
                return response
                
            except Exception as e:
                # Release reserved tokens on error
                self.token_service.release_reserved_tokens(reservation_id)
                return {"error": f"Request failed: {str(e)}"}
        
        except Exception as e:
            return {"error": f"Token management error: {str(e)}"}
    
    def get_provider_status(self) -> Dict[str, Any]:
        """Get status of all providers."""
        return {
            "providers": list(self.providers.keys()),
            "status": "All providers initialized",
            "supported_operations": ["chat_completion", "text_completion", "embeddings", "list_models"]
        }
