"""Token management service with real business logic."""

from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple
from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..models.user import User, TokenUsageLog, SubscriptionPlan, UserSubscription


class TokenService:
    """Service for managing user token balances and consumption."""
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_user_subscription_plan(self, user: User) -> SubscriptionPlan:
        """Get user's current subscription plan, defaulting to free."""
        subscription = (
            self.db.query(UserSubscription)
            .filter(UserSubscription.user_id == user.id)
            .filter(UserSubscription.status == "active")
            .first()
        )
        
        if subscription:
            return subscription.plan
        
        # Return free plan as default
        free_plan = (
            self.db.query(SubscriptionPlan)
            .filter(SubscriptionPlan.name == "free")
            .first()
        )
        
        if not free_plan:
            # Create default free plan if it doesn't exist
            free_plan = SubscriptionPlan(
                name="free",
                display_name="Free Plan",
                monthly_tokens=10000,
                price_monthly=Decimal("0.00"),
                features={"models": ["basic"], "support": "community"},
                is_active=True
            )
            self.db.add(free_plan)
            self.db.commit()
            self.db.refresh(free_plan)
        
        return free_plan
    
    def get_current_period_dates(self, user: User) -> Tuple[datetime, datetime]:
        """Get the current billing period start and end dates."""
        subscription = (
            self.db.query(UserSubscription)
            .filter(UserSubscription.user_id == user.id)
            .filter(UserSubscription.status == "active")
            .first()
        )
        
        if subscription and subscription.current_period_start and subscription.current_period_end:
            return subscription.current_period_start, subscription.current_period_end
        
        # For free users or users without active subscription, use monthly periods
        now = datetime.utcnow()
        period_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        # Calculate next month
        if period_start.month == 12:
            period_end = period_start.replace(year=period_start.year + 1, month=1)
        else:
            period_end = period_start.replace(month=period_start.month + 1)
        
        return period_start, period_end
    
    def get_tokens_used_this_period(self, user: User) -> int:
        """Get total tokens used in the current billing period."""
        period_start, period_end = self.get_current_period_dates(user)
        
        result = (
            self.db.query(func.sum(TokenUsageLog.tokens_used))
            .filter(TokenUsageLog.user_id == user.id)
            .filter(TokenUsageLog.created_at >= period_start)
            .filter(TokenUsageLog.created_at < period_end)
            .scalar()
        )
        
        return result or 0
    
    def get_token_balance(self, user: User) -> Dict[str, Any]:
        """Get user's current token balance and limits."""
        plan = self.get_user_subscription_plan(user)
        tokens_used = self.get_tokens_used_this_period(user)
        tokens_remaining = max(0, plan.monthly_tokens - tokens_used)
        
        period_start, period_end = self.get_current_period_dates(user)
        
        return {
            "tokens_remaining": tokens_remaining,
            "tokens_used": tokens_used,
            "monthly_limit": plan.monthly_tokens,
            "plan_name": plan.name,
            "plan_display_name": plan.display_name,
            "period_start": period_start.isoformat(),
            "period_end": period_end.isoformat(),
            "usage_percentage": round((tokens_used / plan.monthly_tokens) * 100, 2) if plan.monthly_tokens > 0 else 0
        }
    
    def check_token_availability(self, user: User, tokens_requested: int) -> Tuple[bool, str]:
        """Check if user has enough tokens available."""
        balance = self.get_token_balance(user)
        
        if balance["tokens_remaining"] < tokens_requested:
            return False, f"Insufficient tokens. Requested: {tokens_requested}, Available: {balance['tokens_remaining']}"
        
        return True, "OK"
    
    def reserve_tokens(self, user: User, amount: int, provider: str, model_name: str, request_type: str) -> Dict[str, Any]:
        """Reserve tokens for a request (check availability)."""
        available, message = self.check_token_availability(user, amount)
        
        if not available:
            return {
                "success": False,
                "message": message,
                "tokens_reserved": 0
            }
        
        return {
            "success": True,
            "message": "Tokens reserved successfully",
            "tokens_reserved": amount,
            "provider": provider,
            "model_name": model_name,
            "request_type": request_type
        }
    
    def consume_tokens(
        self, 
        user: User, 
        amount: int, 
        provider: str, 
        model_name: str, 
        request_type: str,
        cost_usd: Optional[float] = None,
        request_metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Consume tokens and log usage."""
        # Check availability first
        available, message = self.check_token_availability(user, amount)
        
        if not available:
            return {
                "success": False,
                "message": message,
                "tokens_consumed": 0
            }
        
        # Log the token usage
        usage_log = TokenUsageLog(
            user_id=user.id,
            provider=provider,
            model_name=model_name,
            tokens_used=amount,
            cost_usd=cost_usd or 0.0,
            request_type=request_type,
            request_metadata=request_metadata or {}
        )
        
        self.db.add(usage_log)
        self.db.commit()
        
        # Get updated balance
        updated_balance = self.get_token_balance(user)
        
        return {
            "success": True,
            "message": "Tokens consumed successfully",
            "tokens_consumed": amount,
            "tokens_remaining": updated_balance["tokens_remaining"],
            "usage_percentage": updated_balance["usage_percentage"]
        }
    
    def get_rate_limits(self, user: User) -> Dict[str, int]:
        """Get rate limits based on user's subscription plan."""
        plan = self.get_user_subscription_plan(user)
        
        # Default rate limits
        rate_limits = {
            "per_minute": 60,
            "per_hour": 1000,
            "per_day": 10000
        }
        
        # Adjust based on plan features
        if plan.features:
            max_requests_per_minute = plan.features.get("max_requests_per_minute", 60)
            rate_limits.update({
                "per_minute": max_requests_per_minute,
                "per_hour": max_requests_per_minute * 60,
                "per_day": max_requests_per_minute * 60 * 24
            })
        
        # Plan-specific adjustments
        if plan.name == "free":
            rate_limits.update({
                "per_minute": 10,
                "per_hour": 300,
                "per_day": 1000
            })
        elif plan.name == "pro":
            rate_limits.update({
                "per_minute": 100,
                "per_hour": 3000,
                "per_day": 50000
            })
        elif plan.name == "enterprise":
            rate_limits.update({
                "per_minute": 500,
                "per_hour": 15000,
                "per_day": 200000
            })
        
        return rate_limits
    
    def get_usage_stats(self, user: User, days: int = 30) -> Dict[str, Any]:
        """Get detailed usage statistics for the user."""
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        # Get usage logs for the period
        logs = (
            self.db.query(TokenUsageLog)
            .filter(TokenUsageLog.user_id == user.id)
            .filter(TokenUsageLog.created_at >= cutoff_date)
            .all()
        )
        
        if not logs:
            return {
                "total_tokens": 0,
                "total_cost": 0.0,
                "tokens_by_provider": {},
                "cost_by_provider": {},
                "tokens_by_model": {},
                "tokens_by_request_type": {},
                "daily_usage": []
            }
        
        # Aggregate data
        total_tokens = sum(log.tokens_used for log in logs)
        total_cost = sum(log.cost_usd or 0.0 for log in logs)
        
        # Group by provider
        tokens_by_provider = {}
        cost_by_provider = {}
        for log in logs:
            tokens_by_provider[log.provider] = tokens_by_provider.get(log.provider, 0) + log.tokens_used
            cost_by_provider[log.provider] = cost_by_provider.get(log.provider, 0.0) + (log.cost_usd or 0.0)
        
        # Group by model
        tokens_by_model = {}
        for log in logs:
            model_key = f"{log.provider}/{log.model_name}"
            tokens_by_model[model_key] = tokens_by_model.get(model_key, 0) + log.tokens_used
        
        # Group by request type
        tokens_by_request_type = {}
        for log in logs:
            tokens_by_request_type[log.request_type] = tokens_by_request_type.get(log.request_type, 0) + log.tokens_used
        
        # Daily usage for the last 30 days
        daily_usage = []
        for i in range(days):
            day = (datetime.utcnow() - timedelta(days=i)).date()
            day_logs = [log for log in logs if log.created_at.date() == day]
            daily_tokens = sum(log.tokens_used for log in day_logs)
            daily_cost = sum(log.cost_usd or 0.0 for log in day_logs)
            
            daily_usage.append({
                "date": day.isoformat(),
                "tokens": daily_tokens,
                "cost": daily_cost
            })
        
        daily_usage.reverse()  # Most recent first
        
        return {
            "total_tokens": total_tokens,
            "total_cost": round(total_cost, 4),
            "tokens_by_provider": tokens_by_provider,
            "cost_by_provider": {k: round(v, 4) for k, v in cost_by_provider.items()},
            "tokens_by_model": tokens_by_model,
            "tokens_by_request_type": tokens_by_request_type,
            "daily_usage": daily_usage
        }


class TokenPricingService:
    """Service for calculating token costs based on provider and model."""
    
    # Token costs per 1K tokens (in USD)
    TOKEN_COSTS = {
        "openrouter": {
            "gpt-3.5-turbo": {"input": 0.0015, "output": 0.002},
            "gpt-4": {"input": 0.03, "output": 0.06},
            "gpt-4-turbo": {"input": 0.01, "output": 0.03},
            "claude-3-sonnet": {"input": 0.003, "output": 0.015},
            "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
        },
        "glama": {
            "llama-2-7b": {"input": 0.0002, "output": 0.0002},
            "llama-2-13b": {"input": 0.0004, "output": 0.0004},
            "llama-2-70b": {"input": 0.0008, "output": 0.0016},
        },
        "requesty": {
            "mistral-7b": {"input": 0.0002, "output": 0.0002},
            "mixtral-8x7b": {"input": 0.0006, "output": 0.0006},
        }
    }
    
    @classmethod
    def calculate_cost(
        cls, 
        provider: str, 
        model_name: str, 
        input_tokens: int = 0, 
        output_tokens: int = 0
    ) -> float:
        """Calculate cost for token usage."""
        provider_costs = cls.TOKEN_COSTS.get(provider.lower(), {})
        model_costs = provider_costs.get(model_name.lower(), {"input": 0.001, "output": 0.001})
        
        input_cost = (input_tokens / 1000) * model_costs["input"]
        output_cost = (output_tokens / 1000) * model_costs["output"]
        
        return round(input_cost + output_cost, 6)
    
    @classmethod
    def get_model_pricing(cls, provider: str, model_name: str) -> Dict[str, float]:
        """Get pricing information for a specific model."""
        provider_costs = cls.TOKEN_COSTS.get(provider.lower(), {})
        return provider_costs.get(model_name.lower(), {"input": 0.001, "output": 0.001})
