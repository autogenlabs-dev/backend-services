# Utility functions
