#!/usr/bin/env python3
"""Simple test script to verify our FastAPI application works"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from app.main import app
    print("Successfully imported FastAPI app")
    
    # Test basic functionality
    print("FastAPI app created successfully")
    print(f"App title: {app.title}")
    print(f"Available routes:")
    for route in app.routes:
        if hasattr(route, 'path'):
            print(f"   - {route.path}")
    
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(("127.0.0.1", 8000))
    if result == 0:
        print("Port 8000 already in use, skipping server start.")
    else:
        print("\nStarting server...")
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
    sock.close()
    
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
