#!/usr/bin/env python3
"""
Test script for FastAPI application
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.main import app
from app.config import settings
print("FastAPI application imported successfully!")
print(f"App title: {app.title}")
print(f"Debug mode: {settings.debug}")
print(f"API prefix: {settings.api_v1_str}")

# Test endpoints
print("\nAvailable endpoints:")
for route in app.routes:
    if hasattr(route, 'methods') and hasattr(route, 'path'):
        print(f"  {list(route.methods)[0]} {route.path}")
