"""empty initial database setup (placeholder to fix Alembic errors)

Revision ID: 813c23621078
Revises: 
Create Date: 2025-06-03
"""

revision = '813c23621078'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    pass
