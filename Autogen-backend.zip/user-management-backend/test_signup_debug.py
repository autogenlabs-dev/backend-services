#!/usr/bin/env python3
"""Test signup endpoint to debug the 500 error"""

import requests
import json

def test_signup():
    url = "http://localhost:8000/auth/signup"
    
    # Test data
    user_data = {
        "email": "test@example.com",
        "password": "testpassword123",
        "full_name": "Test User"
    }
    
    try:
        response = requests.post(url, json=user_data)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code == 500:
            print("Got 500 error - this indicates a server-side issue")
        
    except Exception as e:
        print(f"Request failed: {e}")

if __name__ == "__main__":
    test_signup()
